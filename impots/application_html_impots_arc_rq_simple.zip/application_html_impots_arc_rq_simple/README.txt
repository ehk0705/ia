Application HTML simple - Impôts ARC et Revenu Québec

Utilisation :
1. Ouvrir index.html.
2. Aller dans Téléversement.
3. Sélectionner les documents PDF/JPG/PNG.
4. Cliquer sur Analyser les documents.

Cette version :
- fonctionne sans serveur ;
- ne crée pas de problème CORS ;
- ne nécessite pas FastAPI ;
- classe les documents selon leur nom ;
- prépare les lignes ARC et Revenu Québec ;
- n'invente aucun montant.

Limite :
Elle ne fait pas encore l'OCR réel. Pour lire les montants dans les documents scannés ou PDF, il faudra une version serveur.
